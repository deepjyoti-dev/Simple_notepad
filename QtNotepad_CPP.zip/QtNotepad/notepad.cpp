#include "notepad.h"

Notepad::Notepad(QWidget *parent)
    : QMainWindow(parent), textEdit(new QTextEdit(this))
{
    setCentralWidget(textEdit);

    QMenu *fileMenu = menuBar()->addMenu("File");

    QAction *newAct = new QAction("New", this);
    QAction *openAct = new QAction("Open...", this);
    QAction *saveAct = new QAction("Save", this);
    QAction *exitAct = new QAction("Exit", this);

    fileMenu->addAction(newAct);
    fileMenu->addAction(openAct);
    fileMenu->addAction(saveAct);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAct);

    connect(newAct, &QAction::triggered, this, &Notepad::newFile);
    connect(openAct, &QAction::triggered, this, &Notepad::openFile);
    connect(saveAct, &QAction::triggered, this, &Notepad::saveFile);
    connect(exitAct, &QAction::triggered, this, &Notepad::exitApp);
}

void Notepad::newFile()
{
    textEdit->clear();
    currentFile.clear();
}

void Notepad::openFile()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open File");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        textEdit->setText(in.readAll());
        currentFile = fileName;
    } else {
        QMessageBox::warning(this, "Error", "Could not open file.");
    }
}

void Notepad::saveFile()
{
    QString fileName = currentFile;
    if (fileName.isEmpty())
        fileName = QFileDialog::getSaveFileName(this, "Save File");

    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&file);
            out << textEdit->toPlainText();
            currentFile = fileName;
        } else {
            QMessageBox::warning(this, "Error", "Could not save file.");
        }
    }
}

void Notepad::exitApp()
{
    QApplication::quit();
}
