#include <QApplication>
#include "notepad.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Notepad window;
    window.resize(600, 400);
    window.show();
    return app.exec();
}
